const countdownTime = 5;
let remainingTime = countdownTime;
let animationFrameId;
let startTime;

const countdownElement = document.getElementById('countdown');
const buttonElement = document.getElementById('myButton');

// Bắt đầu đếm ngược khi trang đã tải hoàn thành
document.addEventListener('DOMContentLoaded', () => {
    startCountdown();
});

function startCountdown() {
    startTime = Date.now();
    animateCountdown();
}
// document.addEventListener('visibilitychange', () => {
//     if (document.visibilityState === 'visible') {
//         // Trang đã quay lại, tiếp tục đếm ngược
//         startCountdown();
//     } else {
//         // Trang đã chuyển đi, tạm dừng đếm ngược
//         clearInterval(countdownInterval);
//     }
// });
function animateCountdown() {
    const currentTime = Date.now();
    const elapsedTime = currentTime - startTime;
    const remainingSeconds = Math.max(0, Math.ceil((countdownTime * 1000 - elapsedTime) / 1000));

    countdownElement.textContent = `Thời gian còn lại: ${remainingSeconds} giây`;

    if (remainingSeconds > 0) {
        animationFrameId = requestAnimationFrame(animateCountdown);
    } else {
        countdownElement.textContent = 'Thời gian đã hết';
        buttonElement.textContent = 'Mở trang khác';

        // Vô hiệu hóa nút sau khi đếm kết thúc
        buttonElement.disabled = true;

        // Thêm lớp mới để kích hoạt trạng thái :active trong CSS
        buttonElement.classList.add('my-active-button');
    }
}

// Ngừng đếm thời gian nếu cần
function stopCountdown() {
    cancelAnimationFrame(animationFrameId);
}
